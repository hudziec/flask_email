console.log('hit');

$("#username").attr("placeholder", "Username");
